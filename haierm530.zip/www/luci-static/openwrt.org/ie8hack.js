window.onload = function  () {
	alert(123)
}

















//定义选取dom函数
function getEles (e) {
	return document.querySelectorAll(e)
}